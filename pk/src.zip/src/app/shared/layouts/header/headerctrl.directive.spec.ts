import { HeaderctrlDirective } from './headerctrl.directive';

describe('HeaderctrlDirective', () => {
  it('should create an instance', () => {
    const directive = new HeaderctrlDirective();
    expect(directive).toBeTruthy();
  });
});
