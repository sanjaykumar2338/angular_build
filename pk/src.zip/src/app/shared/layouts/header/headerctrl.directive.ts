import { Directive } from '@angular/core';

@Directive({
  selector: '[appHeaderctrl]'
})
export class HeaderctrlDirective {

  constructor() { }

}
