import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-landfoot',
  templateUrl: './landfoot.component.html',
  styleUrls: ['./landfoot.component.css']
})
export class LandfootComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
