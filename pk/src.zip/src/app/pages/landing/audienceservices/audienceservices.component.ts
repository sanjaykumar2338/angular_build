import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-audienceservices',
  templateUrl: './audienceservices.component.html',
  styleUrls: ['./audienceservices.component.css']
})
export class AudienceservicesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
