export const environment = {
  production: true,
  apiUrl: "https://walldirectory.com/v2/api/",
  //apiUrl: "http://localhost:3500/api/",
  imgPath: "https://walldirectory.com/v2/api/",
  blogPost: "https://blog.walldirectory.com/wp-json/wp/v2",
  twitterfeed: "https://blog.walldirectory.com/wp-json/wp/v2/twitterfeed/",
  listingfeed: "https://blog.walldirectory.com/wp-json/wp/v2/twitterfeed2/",
  siteUrl: "https://walldirectory.com/",
  sitepath: "https://walldirectory.com",
  //siteUrl: "http://localhost:4200/",
  //sitepath: "http://localhost:4200",
  freePackage: "766",
  location_apikey: "bd67a9f9947508bf4671e24330992cc3"
};
